public class Main {
    public static void main(String[] args){
        int[][] matriz1 = {
                {1,0},
                {0,1}
        };
        int[][] matriz2 = {
                {1,0},
                {0,1}
        };
        MatrixUtilities.show(matriz1);
        System.out.println(MatrixUtilities.isMatrix(matriz1));
        System.out.println(MatrixUtilities.isIdentity(matriz1));
        MatrixUtilities.multiplyBy(matriz1, 5);
        System.out.println(MatrixUtilities.areCompatibleForSum(matriz1,matriz2));
        MatrixUtilities.sumOf(matriz1, matriz2);

        System.out.println(CharacterDrawingUtilities.drawElement("+"));
        CharacterDrawingUtilities.drawNewLine();
        CharacterDrawingUtilities.drawHorizontalSegmentWith(10);
        CharacterDrawingUtilities.drawFilledRectangleWith(10,10);
        CharacterDrawingUtilities.drawEmptyRectangleWith(10,10);
    }
}
