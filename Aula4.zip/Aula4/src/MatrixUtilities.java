public class MatrixUtilities {
    public static void show (int[][] matriz){
        for (int i = 0; i < matriz.length; i++){
            for (int x = 0; x < matriz[i].length; x++){
                System.out.print(matriz[i][x] + "\t");
            }
            System.out.print("\n");
        }
    }
    public static boolean isMatrix (int[][] matriz){
        int tamanhoInicial = matriz[0].length;
        for (int i = 0; i < matriz.length; i++){
            if (matriz[i].length != tamanhoInicial){
                return false;
            }
        }
        return true;
    }
    public static boolean isIdentity (int[][] matriz){
        for (int i = 0; i < matriz.length; i++){
            for (int x = 0; x < matriz[i].length; x++){
                if (i == x){
                    if (matriz[i][x] != 1){
                        return false;
                    }
                }
                else {
                    if (matriz[i][x] != 0){
                        return false;
                    }
                }
            }
        }
        return true;
    }
    public static void multiplyBy (int[][] matriz, int constante){
        for (int i = 0; i < matriz.length; i++){
            for (int x = 0; x < matriz[i].length; x++){
                System.out.print(matriz[i][x]*5 + "\t");
            }
            System.out.print("\n");
        }
    }
    public static boolean areCompatibleForSum (int[][] matriz1, int[][] matriz2){
        if (matriz1.length != matriz2.length) {
            return false;
        }
        else
        {
            for (int i = 0; i < matriz1.length; i++) {
                if (matriz1[i].length != matriz2[i].length) {
                    return false;
                }
            }
        }
        return true;
    }
    public static void sumOf (int[][] matriz1, int[][] matriz2) {
        if (areCompatibleForSum(matriz1, matriz2) == true) {
            for (int i = 0; i < matriz1.length; i++) {
                for (int x = 0; x < matriz1.length; x++) {
                    System.out.print(matriz1[i][x] + matriz2[i][x] + "\t");
                }
                System.out.print("\n");
            }
        }
    }
}
