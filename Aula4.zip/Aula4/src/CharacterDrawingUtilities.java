public class CharacterDrawingUtilities {
    public static String drawElement (String element){
        return element;
    }
    public static void drawNewLine (){
        System.out.print(" ");
    }
    public static void drawHorizontalSegmentWith (int largura){
        for (int x=0; x<largura; x++){
            drawNewLine();
            System.out.print(drawElement("+"));
        }
    }
    public static void drawFilledRectangleWith (int altura, int largura){
        for (int i=0; i<altura+1; i++){
            drawHorizontalSegmentWith(largura);
            System.out.println();
        }
    }
    public static void drawEmptyRectangleWith (int altura, int largura){
        drawHorizontalSegmentWith(largura);
        System.out.print("\n");
        for (int x=0; x<altura-2; x++){
            drawNewLine();
            System.out.print("+");
            for (int y=0; y<largura+7; y++){
                drawNewLine();
            }
            System.out.print("+");
            System.out.print("\n");
        }
        drawHorizontalSegmentWith(largura);
    }
}
